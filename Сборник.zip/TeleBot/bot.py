import config
import logging
import calendar
import random
import pyfiglet
from os import system as os
from aiogram import Bot, Dispatcher
from aiogram import executor, types
from tabulate import tabulate
from filters import IsAdminFilter
from rich import print
from rich.console import Console


#Activated bot
console = Console()
logging.basicConfig(level = logging.INFO)
bot = Bot(token = config.TOKEN)
dp = Dispatcher(bot)
print(pyfiglet.figlet_format("Telegram\nModerator",font="slant"))
dp.filters_factory.bind(IsAdminFilter)

#Teg console
table = [
["Script by: ","あесконечный"],
["TeleBot: ","Модератор чата"],
["Status: ","Бот активный!"]
]
console.print(tabulate(table),"\n")
#---------------------------------------
#Peremen libs
cal = calendar.month(2022,7)
rand = random.randint(1, 100)
#---------------------------------------
tableTop = [

["1)","colorama"],
["2)","rich"],
["3)","Kiviy"],
["4)","pyfiglet"]

]
#---------------------------------------
tableAdm = [

["1)","@Aplleas"],
["2)","@NemoY73"],
["2)","@DK_T3"]

]
#---------------------------------------
tableUseLibs = [

["1)","pyfiglet"],
["2)","rich"],
["3)","aiogram"],
["4)","tabulate"],
["5)","random"],
["6)","calendar"],
["7)","logging"],
["8)","filters"],
["9)","os"],
["10)","config"]

]
#---------------------------------------
list = (
"Лесок","Тупой?","Глупый",
"Свинья", "Дед инфаркт",
"Скоро умрешь", "Секаса",
"Армянский секс","Течешь"
)

#---------------------------------------

#Help comand bot
@dp.message_handler(is_admin=True,commands=["help"],commands_prefix="!")
async def cmd_ban(message: types.Message):
	if not message.reply_to_message:
		await message.reply("""

		
	 : : Основные Команды : :
		
		| >> /spam 
		| >> /calendar
		| >> /randnum 
		| >> /WhoAmI?

| !top | !administration | !infoCom

		""")
		console.print("\nСообщение [bold green][u]'!help'[/u][/bold green] выведено в чат!",style="bold cyan")
		return

#Command spam
@dp.message_handler(is_admin=True, commands=["spam"],commands_prefix="/")
async def message(message: types.Message):
	if not message.reply_to_message:
		console.print("\nКоманда [bold green][u]!spam[/u][/bold green] использована!",style="bold cyan")
		await message.reply("Ок\n"*900)

#Command calendar		
@dp.message_handler(is_admin=True,commands=["calendar"],commands_prefix="/")
async def send_message(message: types.Message):
	if not message.reply_to_message:
		console.print("Команда [bold green][u]/calendar[/u][/bold green] использована!",style="bold cyan")
		await message.reply(cal)

#Command random number
@dp.message_handler(is_admin=True,commands=["randnum"],commands_prefix="/")
async def message_random(message: types.Message):
	if not message.reply_to_message:
		console.print(f"[bold yellow][u]!randnum[/u][/bold yellow] [bold red]>>[/bold red] Выпало числи под номером: [bold green]{rand}[/bold green]",style="bold cyan")
		await message.reply("Твое число: "+str(rand))

@dp.message_handler(is_admin=True,commands=["top"],commands_prefix="!")
async def message_top(message: types.Message):
	if not message.reply_to_message:
		console.print("Открыт [bold green][u]!top[/u][/bold green] список",style="bold cyan")
		await message.reply(""" 

>> /toplib <<
>> /uselibs <<
		
""")
		
@dp.message_handler(is_admin=True,commands=["toplib"],commands_prefix="/")
async def message_toplib(message: types.Message):
	if not message.reply_to_message:
		console.print("[bold yellow]!toplib[/bold yellow] [bold green]>>[/bold green] Топ выведен успешно!",style="bold cyan")
		await message.reply(tabulate(tableTop))
		
@dp.message_handler(is_admin=True,commands=["administration"],commands_prefix="!")
async def message_adm(message: types.Message):
	if not message.reply_to_message:
		console.print("[bold yellow]!administation[/bold yellow] [bold green]>>[/bold green] Вывел список администрации!",style="bold cyan")
		await message.reply(tabulate(tableAdm))
	
@dp.message_handler(is_admin=True,commands=["uselibs"],commands_prefix="/")
async def message_adm(message: types.Message):
	if not message.reply_to_message:
		console.print("[bold yellow]/uselibs[/bold yellow] [bold green]>>[/bold green] Вывел все использованные либы!",style="bold cyan")
		await message.reply(tabulate(tableUseLibs))

@dp.message_handler(is_admin=True,commands=["WhoAmI"],commands_prefix="/")
async def message_adm(message: types.Message):
	if not message.reply_to_message:
		console.print(f"[bold yellow]/WhoAmI[/bold yellow] [bold green]>>[/bold green] Сказал человеку, что он: {list}?!",style="bold cyan")
		await message.reply("Ты у нас: "+random.choice(list))


@dp.message_handler(is_admin=True,commands=["infoCom"],commands_prefix="!")
async def message_infoCom(message: types.Message):
	if not message.reply_to_message:
		console.print("Отображенна [bold green][u]!infoCom[/u][/bold green] в чате",style="bold cyan")
		await message.reply("""
		
: : Инфрмация о командах : :
	
— >> top << — 
Откроет список топов

— >> uselibs << — 
Использованные либы ботом

— >> administration << —
Покажет список администраторов чата

— >> toplib << —
Покажет какие либы лучше

— >> randnum << —
Скинет случайное число до ста

— >> WhoAmI << —
Расскажет, кто ты на самом деле

— >> calendar << —
Откроет календарь

— >> spam << —
Не надо, лучше не надо

	
""")


#Automatick function
#Remove new user "join to chat"
@dp.message_handler(content_types=["new_chat_members"])
async def on_user_joined(message: types.Message):
	console.print("Сообщение [bold cyan][u]'join new user'[/u][/bold cyan] удалено!")
	await message.delete()

#Filter bot
@dp.message_handler()
async def filter_message(message: types.Message):

	if "хуй" in message.text:
		print("[bold red]Нецензурная брань удалена![/bold red]")
		await message.delete()
	elif "Хуй" in message.text:
		print("[bold red]Нецензурная брань удалена![/bold red]")
		await message.delete()
	elif "пизда" in message.text:
		print("[bold red]Нецензурная брань удалена![/bold red]")
		await message.delete()
	elif "Пизда" in message.text:
		print("[bold red]Нецензурная брань удалена![/bold red]")
		await message.delete()
	elif "ебать" in message.text:
		print("[bold red]Нецензурная брань удалена![/bold red]")
		await message.delete()
	elif "Ебать" in message.text:
		print("[bold red]Нецензурная брань удалена![/bold red]")
		await message.delete()
	elif "пидор" in message.text:
		print("[bold red]Нецензурная брань удалена![/bold red]")
		await message.delete()	
	elif "Пидор" in message.text:
		print("[bold red]Нецензурная брань удалена![/bold red]")
		await message.delete()
	elif "пидр" in message.text:
		print("[bold red]Нецензурная брань удалена![/bold red]")
		await message.delete()
	elif "еб" in message.text:
		print("[bold red]Нецензурная брань удалена![/bold red]")
		await message.delete()
	elif "ёб" in message.text:
		print("[bold red]Нецензурная брань удалена![/bold red]")
		await message.delete()
	elif "Еб" in message.text:
		print("[bold red]Нецензурная брань удалена![/bold red]")
		await message.delete()
	elif "Ёб" in message.text:
		print("[bold red]Нецензурная брань удалена![/bold red]")
		await message.delete()
	elif "хер" in message.text:
		print("[bold red]Нецензурная брань удалена![/bold red]")
		await message.delete()
	elif "Хер" in message.text:
		print("[bold red]Нецензурная брань удалена![/bold red]")
		await message.delete()
	elif "хрен" in message.text:
		print("[bold red]Нецензурная брань удалена![/bold red]")
		await message.delete()
	elif "Хрен" in message.text:
		print("[bold red]Нецензурная брань удалена![/bold red]")
		await message.delete()
	elif "хуеть" in message.text:
		print("[bold red]Нецензурная брань удалена![/bold red]")
		await message.delete()
	elif "ахуел" in message.text:
		print("[bold red]Нецензурная брань удалена![/bold red]")
		await message.delete()
	elif "Ахуел" in message.text:
		print("[bold red]Нецензурная брань удалена![/bold red]")
		await message.delete()
	elif "охуел" in message.text:
		print("[bold red]Нецензурная брань удалена![/bold red]")
		await message.delete()


#run long-polling
if __name__ ==  "__main__":
	executor.start_polling(dp, skip_updates=True)
