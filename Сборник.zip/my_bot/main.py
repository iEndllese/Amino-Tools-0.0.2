import aminofix, concurrent.futures, pyfiglet
from threading import Thread
from colored import fore, back, style, attr
from getpass import getpass
attr(0)
print(fore.GREEN + style.BOLD)

client = aminofix.Client()

print(pyfiglet.figlet_format("Spam", font="larry3d"))


while True:
	try:
		email = input("Введите ваш email: ")
		password = getpass("Введите ваш пароль: ")
		client.login(email = email, password = password)
		break
	except Exception as error:
		print(f"Ошибка ввода данных! \n {error} \n")

while True:
	try:
		chat = client.get_from_code(input("Введите ссылку на чат: ")).json
		chatId = chat["extension"]["linkInfo"]["objectId"]
		comId = chat["extension"]["linkInfo"]["ndcId"]
		sub_client = aminofix.SubClient(comId = comId, profile = client.profile)
		break
	except Exception as error:
		print(f"Ошибка! \n {error} \n")


message = input("Ваше сообщения: ")
mess_type = input("Тип сообщения: ")

try:
	client.join_community(comId = comId)
	com = "Выполнено!"
except:
	com = "Произошла ошибка!"

try:
	sub_client.join_chat(chatId = chatId)
	chat_ = "Выполнено!"
except:
	chat_ = "Произошла ошибка!"

print(f"Вход в соощество: {com} \n Вход в чат: {chat_}")

for spam_ in range(5):
	Thread(target = spam, args = (sub_client, chatId, message, mess_type)).start()

def spam(sub_client, chatId, message, mess_type):
	try:
		print("Спам запущен!")
		with concurrent.futures.ThreadPoolExecutor(max_workers=150) as executor:
			MM = [
			executor.submit(
			sub_client.send_message,
			chatId,
			message,
			mess_type) for MM in range(100000)]

	
	except Exception as error:
		print(f"Ошибка!\n {error}")

