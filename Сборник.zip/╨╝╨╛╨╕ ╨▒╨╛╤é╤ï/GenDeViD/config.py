import pyfiglet

TegPfg = pyfiglet.figlet_format("DeviceGener", font="larry3d", width=50)

deadline = ("\n" + "—" *60 + "\n")

SBY = "\t\t\t\tScript by あесконечный"
