from colorama import Fore, Style

print(Fore.CYAN+Style.BRIGHT)

table = [

"<<1>> || Показать список дел на сегодня",
"<<2>> || Показать список дел на завтра",

]