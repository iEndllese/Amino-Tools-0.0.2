
#Список задач 0.0.1

import config
from os import system as os
from colorama import Fore, Style

#Список созданых/открываемых листов

my_file = open("list.txt","r")
my_file2 = open("list2.txt","r")

#Цветовой сценарий для текста

Y = Fore.YELLOW ; G = Fore.GREEN
C = Fore.CYAN ; R = Fore.RED
bg = Style.BRIGHT

#Отображения config

print(config.table[0])
print(config.table[1])

#Выбор нужного значение

inp = input(Y+bg+"\nВыберите цифру: ")
os("cls||clear")

#Цикл в зависимости от выбора

if inp == "1":
	for line in my_file:
		print(G, bg, line, end="")

elif inp == "2":
	for lineTwo in my_file2:
		print(G, bg, lineTwo, end="")

else:
	print(R+bg+"Неверно введены данные!")
