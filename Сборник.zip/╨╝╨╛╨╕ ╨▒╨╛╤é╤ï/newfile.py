from os import system as os

file = open("new_file.txt","w+")
file = write("Hello")
print(file)