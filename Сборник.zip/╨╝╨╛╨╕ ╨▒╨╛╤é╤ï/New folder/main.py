import config
import os

print(config.teg)
print(config.line)
mat = config.mat1 ; mat1 = config.mat2
mat2 = config.mat3 ; mat3 = config.mat4
mat4 = config.mat5 ; mat5 = config.mat6
calculate = input("Введите значение >> ")
a = float(input("Введите первые цифры >> "))
b = float (input("Введите вторые цифры >> "))

if calculate == mat:
	print(config.text1)

elif calculate == mat1:
	print(config.text1)
	
elif calculate == mat2:
	print(config.text1)

elif calculate == mat3:
	print(config.text1)

elif calculate == mat4:
	c = a + b
	print(config.textwin, c)

elif calculate == mat5:
	c = a - b
	print(config.textwin, c)
	
else:
	while True:
		print("Неверно введена операция!")
		inp = input(config.text2)

		if inp == "Да":
			print("А во что ты хочешь потграть?")
			print(config.SELECT[0])
			print(config.SELECT[1])
			print(config.sel)
		
		elif inp == "Нет":
			os.system("clear || cls")
		else:
			print("Opss...")