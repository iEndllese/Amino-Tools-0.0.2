import pyfiglet as pfg
from colorama import Fore, Style

Y = Fore.YELLOW + Style.BRIGHT
G = Fore.GREEN + Style.BRIGHT
C = Fore.CYAN + Style.BRIGHT

teg = G+pfg.figlet_format("CalBot",font="5lineoblique")

line = Y+"""
\n
                                     Warning!
                                     
                    this bot is under development

"""+C ;

mat1 = "хуй "; mat2 = "Хрен" ; mat3 = "Хуй"
mat4 = "хрен" ; mat5 = "+" ; mat6 = "-"
text1 = "Пиздуй нахуй отсюда, уебище аморальное"
textwin = "Держи, сученыш: "
text2 = "Будем играть?(Да/Нет): "

SELECT = [

"[1] || Куклы",
"[2] || В тебя"


]
sel = input()