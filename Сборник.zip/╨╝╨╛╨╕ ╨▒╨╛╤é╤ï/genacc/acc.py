import random
import pyfiglet
from colorama import Fore, Style
G = Fore.LIGHTGREEN_EX
R = Fore.LIGHTRED_EX
C = Fore.LIGHTCYAN_EX
Y = Fore.LIGHTYELLOW_EX
B = Fore.LIGHTBLUE_EX
print(G)#А ты что думал?
print(pyfiglet.figlet_format("PASSGEN!",font="slant"))
print(f"{Y}\t \t\t\t: : : Бесконечный : : : \n")
print(R+"_"*74)
chars = "ABCDKERWQIPOLNCOOXZZQRTYYUIOPMNBXVCXXVNMLOSHSVAHDG"
number = int(input(f"\n{B}Количество паролей: {C}"))
length = int(input(f"{B}Длина паролей: {C}"))
print("\n")
file = open("new_pass.txt","w+")
for n in range(number):
    password =''
    for i in range(length):
        password += random.choice(chars)
    file.write(password+"\n")
    print(G+">>",Y+password)
    pass

print(f"\n{G}Генерация паролей выполнена успешно!")
file.close()