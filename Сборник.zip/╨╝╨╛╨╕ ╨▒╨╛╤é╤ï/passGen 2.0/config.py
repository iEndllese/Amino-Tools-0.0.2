import pyfiglet

chorse = "a1s2d3f4g5h6j7k8l9AqSwDeFRGHtJyKuLiOPpoZzXvbnmMNBVCZXC0"

BANNER = pyfiglet.figlet_format("PassGen", font="cyberlarge")