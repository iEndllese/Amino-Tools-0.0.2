import telebot

bot = telebot.TeleBot("5589419849:AAFKa5W1L8bqsaLsBCzsMg28DnCFtRgnXBE")

@bot.message_handler(commands=["start"])


def start(message):
	bot.send_message(bot.chat.id, "<b>Добро пожаловать!</b>\nДабы узнать все функции данного бота, пожалуйста, прочтите описание!",parse_mode="html")

bot.polling(none_stop=True)