from time import sleep
from os import system as s
from colorama import Fore, Style
from tabulate import tabulate

n = "\n"
G = Fore.LIGHTGREEN_EX
Y = Fore.LIGHTYELLOW_EX
R = Fore.LIGHTRED_EX
C = "\033[1;96m"

for i in G+"<< UPGRADE PIP >>"+C:
	print(i,end="",flush=True)
	sleep(00.05)
print(n)
s("pip install --upgrade pip")
s("clear")

for i in G+"<< INSTALL BS4 >>"+C:
	print(i,end="",flush=True)
	sleep(00.05)
print(n)
s("pip install bs4")
s("clear")

for i in G+"<< INSTALL UJSON >>"+C:
	print(i,end="",flush=True)
	sleep(00.05)
print(n)
s("pip install --upgrade ujson")
s("clear")

for i in R+"<< UNINSTALL AMINO >>"+C:
	print(i,end="",flush=True)
	sleep(00.05)
print(n)
s("pip uninstall amino -y")
print(n)
s("clear")

for i in R+" << UNINSTALL AMINO.FIX >>"+C:
	print(i,end="",flush=True)
	sleep(00.05)
print(n)
s("pip uninstall Amino.fix -y")
s("clear")

for i in R+"<< UNINSTALL AMINO.PY >>"+C:
	print(i,end="",flush=True)
	sleep(00.05)
print(n)
s("pip uninstall Amino.py -y")
s("clear")

for i in G+"<< INSTALL SAMINO >>"+C:
	print(i,end="",flush=True)
	sleep(00.05)
print(n)
s("pip install samino -U")
s("clear")

for i in G+"<< INSTALL AMINO.FIX >>"+C:
	print(i,end="",flush=True)
	sleep(00.05)
print(n)
s("pip install Amino.fix -U")
s("clear")

for i in G+"<< INSTALL AMINOLIB >>"+C:
	print(i,end="",flush=True)
	sleep(00.05)
print(n)
s("pip install aminolib -U")
s("cls||clear")

print(R)
table = [[f"{Y}Amino",f"{G}Deleted complete!"],[f"{Y}Amino.py",f"{G}Deleted complete!"],[f"{Y}Amino.fix",f"{G}Deleted complete!{R}"]]
print(tabulate(table))
print(G)
table_install = [[G+f"Samino","Installed complete!"],[f"Amino.fix","Installed complete!"],[f"AminoLib","Installed complete!"]]
print(tabulate(table_install))
print(C)
table_py = [[C+f"Python pip",f"{G}Upgrade complete!"],[f"{C}Python ujson",f"{G}Installed complete!"],[f"{C}Python bs4",f"{G}Istalled complete!{C}"]]
print(tabulate(table_py))
sleep(3000)
