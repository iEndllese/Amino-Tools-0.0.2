import time

text = "Shinra, your'e a real goul, dead inside"
a = 1000

while a > 7:
	time.sleep(00.03)
	a -= 7
	print(f"{a+7} - 7 = {a}")

print("\n" + text.upper())