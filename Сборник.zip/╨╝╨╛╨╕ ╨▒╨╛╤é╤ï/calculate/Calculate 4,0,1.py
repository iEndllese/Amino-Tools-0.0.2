import os
import pyfiglet
from colorama import Fore, Style

Y = Fore.YELLOW + Style.BRIGHT
G = Fore.GREEN + Style.BRIGHT
C = Fore.CYAN + Style.BRIGHT
R = Fore.RED + Style.BRIGHT

print(G+pyfiglet.figlet_format("CalBot", font="5lineoblique"))

while True:
	inp = input(C+"\nВведите значение: "+Y)
	
	if inp == "0":
		break
	
	if inp in ("+", "-", "*", "/", "**"):
		a = int(input(C+"Введите первые цифры: "+Y))
		b = int(input(C+"Введите вторые цифры: "+Y))
		os.system("cls || clear")
		
		if inp == "+":
			print(f"{C}Итого: {G} {a} + {b} = " +Y+ str(a + b))
			
		elif inp == "-":
			print(f"{C}Итого: {G} {a} - {b} = " +Y+ str(a - b))
			
		elif inp == "*":
			print(f"{C}Итого: {G}{a} * {b} = " +Y+ str(a * b))
		
		elif inp == "**":
			print(f"{C}Итого: {G}{a} ** {b} = " +Y+ str(a ** b))
		
		elif inp == "/":			
			if b != 0:
				print(f"{C}Итого: {G}{a} / {b} = " +Y+ str(a / b))
			else:
				print(R+"Нельзя делить на ноль!")
				
	else:
		print(R+"Неверно введено значение!")