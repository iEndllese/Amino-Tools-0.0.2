#Calculate 4.2.0
import os
import config
import pyfiglet as pfg
from time import sleep
from colorama import Fore, Style, init
from tabulate import tabulate

init(autoreset = True)

G = Fore.GREEN + Style.BRIGHT ; Y = Fore.YELLOW + Style.BRIGHT ;
C = Fore.CYAN + Style.BRIGHT ; R = Fore.RED + Style.BRIGHT ; 
M = Fore.MAGENTA + Style.BRIGHT ; #I love Apple de Vincant :З

TheEnd = R + "Операция закончена!"

print(M + pfg.figlet_format("CalBot", font="5lineoblique"))
print(G+tabulate(config.TABLE))

while True:
	calculate = input(f"\n{C}Введите значение операции: " + Y)

	if calculate == "0":
		print(TheEnd)
		break

	if calculate in ("+", "-", "*", "/", "**"):
		a = int(input(f"{C}Введи первые цифры: " + Y))
		b = int(input(f"{C}Введи вторые цифры: " + Y))
		os.system("cls || clear")

		if calculate == "+":
			print(f"{M}Итого: {Y}{a}{G} + {Y}{b}{G} = {Y}" + str(a + b))

		elif calculate == "-":
			print(f"{M}Итого: {Y}{a}{G} - {Y}{b}{G} = {Y}" + str(a - b))

		elif calculate == "*":
			print(f"{M}Итого: {Y}{a}{G} * {Y}{b}{G} = {Y}" + str(a * b))

		elif calculate == "/":
			if b == 0:
				print(R+"На ноль нельзя делить!")
			else:
				print(f"{M}Итого: {Y}{a}{G} / {Y}{b}{G} = {Y}" + str(a / b))

		elif calculate == "**":
			print(f"{M}Итого: {Y}{a}{G} ** {Y}{b}{G} = {Y}" + str(a ** b))
					

	else:
		print(R+"Неверно введено значение операции!")



