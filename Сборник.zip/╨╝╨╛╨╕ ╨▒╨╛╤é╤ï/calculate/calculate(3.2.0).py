#Калькулятор 3.2.0
import pyfiglet
from colorama import Fore, Style


#Цветовая схема
Y = Fore.YELLOW + Style.BRIGHT
G = Fore.GREEN+ Style.BRIGHT
C = Fore.CYAN + Style.BRIGHT
R = Fore.RED + Style.BRIGHT


#Тэг через lib pyfiglet
print(C+pyfiglet.figlet_format("CalLate",font="5lineoblique"))


#Ввести строго: + || - || / || *
calculate = input(G+"\nВведите значение: "+C)
a = int(input(G+"Введи первые цифры: "+C))
b = int(input(G+"Введи вторые цифры: "+C))


#Условия работы с данными
if calculate == "+":
	c = a + b
	print(f"{C}Итого: {Y}",str(c))

elif calculate == "-":
	c = a - b
	print(f"{C}Итого: {Y}",str(c))
	
elif calculate == "*":
	c = a * b
	print(f"{C}Итого: {Y}",str(c))

elif calculate == "/":
	c = a / b
	print(f"{C}Итого: {Y}",str(c))
	
elif calculate == "**":
	c = a ** b
	print(f"{C}Итого: {Y}",str(c))
	
else:
	print(f"{R}Неверное значение!")
