import pyfiglet
from tabulate import tabulate
from os import system as os
try:
	import pyfiglet
except:
	os("pip install pyfiglet")
	import pyfiglet

		
print(pyfiglet.figlet_format("Calculate",font="doom"))
table = [["Script by:","あесконечный"],["Name script:","Calculator"],["Status script:","This is only"]]
print(tabulate(table))

a = int(input("\nEnter one number: "))
b = int(input("Enter two number: "))
def suma(x,y):
		return a+b or a-b
print("Result: "+str(suma(a,b)))
