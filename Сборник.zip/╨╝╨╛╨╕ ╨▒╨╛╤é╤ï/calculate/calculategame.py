#Calculate game - бездарная игра,
#бездарный код

from rich import print
from rich.console import Console
from tabulate import tabulate
from os import system as console_os
from colorama import Fore, Style, Back
from time import sleep
console = Console()

G = Fore.LIGHTGREEN_EX+Style.BRIGHT
R = Fore.LIGHTRED_EX+Style.BRIGHT
Y = Fore.LIGHTYELLOW_EX+Style.BRIGHT
C = Fore.LIGHTCYAN_EX+Style.BRIGHT

calculate = input(f"{G}Введи значение:{C} ")
a = float(input(f"{G}Введи первые цифры:{C} "))
b = float(input(f"{G}Введи вторые цифы:{C} "))
console_os("cls||clear")

if calculate == "+":
	c = a + b
	console.print("[bold cyan]Итого: [/bold cyan]"+str(c))
	pass
	
elif calculate == "-":
	c = a - b
	console.print("[bold cyan]Итого: [/bold cyan]"+str(c))
	pass
	
elif calculate == "*":
	c = a * b
	console.print("[bold cyan]Итого: [/bold cyan]"+str(c))
	pass
	
elif calculate == "/":
	c = a / b
	console.print("[bold cyan]Итого: [/bold cyan]"+str(c))
	pass
	
else:
	console.print("\nНеверное значение, пожалуйста, введите [bold yellow][u]правильно[/u][/bold yellow] значение операции",style="bold red")
	
console_os("cls||clear")
	
for number in "183, 467, 911, 362, 927, 466":
		print(number,end="",flush=True)
		sleep(00.10)
		
console_os("cls||clear")
console.print("[bold red][u]Бес[/u][/bold red][bold blue]полезно[/bold blue]"*50)
console_os("cls||clear")
num = input("...: ")

while True:
	if num == "183":
		print("Not...")
		break
	elif num == "467":
		print("Oh....Not")
		break
	elif num == "911":
		print("STAR IS GAME...")
		break
print(G)		
table = [

[f"{G}Autor: ",f"{Y}あесконечный"],
[f"{G}Game: ",f"{Y}Calculate game"],
[f"{G}Goal",f"{Y}Million amino coins"],
["Упс...","Ты проиграаал"]
		
]
print(G+tabulate(table))
console.print("bold cyan]92[/bold cyan][bold yellow]and[/bold yellow][bold cyan]93[/bold cyan] ??",style="green")

