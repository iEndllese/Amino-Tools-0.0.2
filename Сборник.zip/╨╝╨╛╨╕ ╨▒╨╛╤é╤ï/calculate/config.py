

TABLE = [

["Script by", "Apple de Vincant"],
["Telegram", "@iEnablese"],
["Instagram:", "iEnablese"]


]