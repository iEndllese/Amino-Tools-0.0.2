import pyfiglet
import random
from colorama import Fore, Style

C = Fore.CYAN ; G = Fore.GREEN
Y = Fore.YELLOW; B = Fore.BLUE
sb = Style.BRIGHT

tegg = Y+sb+"by あесконечный"
TEG = C+pyfiglet.figlet_format("TextGen", font="slant")

chars = "HDUEBEHLAPPZBCW1OP"
