import config
import random
from os import system as os
print(config.TEG,config.tegg)
from time import sleep as timer


