import aminofix
import json
from os import path
from colorama import Style, Fore
from pyfiglet import figlet_format
from time import sleep

print(Fore.YELLOW+Style.BRIGHT)
print(figlet_format("Vereficator\nAuto", font="rectangles", width=64))
print(Fore.RED+Style.BRIGHT)
for i in "Fixed by Apple de Vincant":
	print(i, end="", flush=True)
	sleep(0.03)
print("\n")
print(Fore.GREEN+Style.BRIGHT)
file = path.dirname(path.abspath(__file__))
acc=path.join(file,"accounts.json")
dictlist=[]
with open(acc) as f:
    dictlist = json.load(f)
    def threadit(acc : dict):
    	email=acc["email"]
    	password=acc["password"]
    	device=acc["deviceId"]
    	
    	client=aminofix.Client(deviceId=device)
    	try:
    		client.login(email,password)
    		print("Verified >>>" ,email)
    		client.logout()
    		x=open("acc.json","a")
    		acc = f'{{"email": "{email}","password": "{password}","device": "{device}"}},'
    		x.write(acc)
    		x.close
    	except:
    				print("error")
    				pass
    				


for amp in dictlist:
	threadit(amp)