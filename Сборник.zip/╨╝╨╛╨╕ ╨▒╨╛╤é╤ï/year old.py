line = """ Добро пожаловать! \nВход на сайт '{syte}' успешно выполнен!"""
syte = input()

old = int(input("Введи свой возраст: "))

if not old >= 18 or old >= 30:
	print("Вход запрещен!")

else:
	print("Вход разрешен!")
	
	