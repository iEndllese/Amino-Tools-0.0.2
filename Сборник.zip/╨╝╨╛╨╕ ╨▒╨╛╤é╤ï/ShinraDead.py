import time

a = 1000
text = ("\nShinra, you're a real ghoul, dead inside")
while a > 7:
	time.sleep(00.03)
	a -= 7
	print(f"{a+7} - 7 = {a}")
print(text.upper())