import os
import amino
import asyncio
from time import sleep
from colorama import Fore
client = amino.AsyncClient()



print(Fore.RED)
for i in "Made by Apple de Vincant":
	print(i, end="", flush=True)
	sleep(0.02)
print("\n")


for i in "\033[1;96mОткровенно, хуета написанная на досуге\nИграйтесь, дети и амино хацкеры с Пентагона ":
	print(i, end="", flush=True)
	sleep(0.02)
print("\n")


async def authorization():
    try:
        await client.login(email=input("\033[1;94mEmail: "), password=input("\033[31;94mPassword: "))
        print("")
        os.system("clear")
        print("\033[1;92mBot logged!")
    except Exception as e:
        print(f"\033[31m{e}")
        await authorization()


async def link_checker():
    try:
        info = (await client.get_from_code(input("Chat link: ")))
        os.system("clear")
        return info
    except Exception as e:
        print(f"\033[31m{e}")
        await link_checker()


async def send_messages(message, message_type, chat_id, sub_client):
    await sub_client.send_message(message=message, messageType=message_type, chatId=chat_id)
    print("\033[37mMessage is send")


async def main():
    await authorization()
    info = await link_checker()
    sub_client = amino.AsyncSubClient(comId=info.comId, profile=client.profile)
    message = input("\033[37mMessage: ")
    message_type = int(input("\033[37mMessage type: "))
    task_count = int(input("\033[37mTask count: "))
    await sub_client.join_chat(info.objectId)
    while True:
        try:
            await asyncio.gather(*[asyncio.create_task(send_messages(message=message,
                                                                     message_type=message_type,
                                                                     sub_client=sub_client,
                                                                     chat_id=info.objectId))
                                   for _ in range(task_count)])
        except Exception as e:
            print(f"\033[31m{e}")
            continue

if __name__ == '__main__':
    asyncio.get_event_loop().run_until_complete(main())
