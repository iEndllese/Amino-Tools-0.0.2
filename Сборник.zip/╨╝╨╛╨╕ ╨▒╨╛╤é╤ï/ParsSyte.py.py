import os




inp = input("Введите свою ссылку: ")


if "https://" in inp:
	os.system(f"start {inp}")
	print(f"Запускаеться сайт! >> {inp}")
	pass

elif "www." in inp:
	inp = "https://" + inp
	os.system(f"start {inp}")
	print(f"Запускаеться сайт! >> {inp}")
	pass

elif ".com" in inp:
	inp = "https://" + inp
	os.system(f"start {inp}")
	print(f"Запускаеться сайт! >> {inp}")
	pass

elif ".ua" in inp:
	inp = "https://" + inp
	os.system(f"start {inp}")
	print(f"Запускаеться сайт! >> {inp}")
	pass

elif ".ru" in inp:
	inp = "https://" + inp
	os.system(f"start {inp}")
	print(f"Запускаеться сайт! >> {inp}")
	pass

elif "http://" in inp:
	os.system(f"start {inp}")
	print(f"Запускаеться сайт! >> {inp}")
	pass

else:
	print("Oops...Кажеться, вы неправильно ввели ссылку")	
