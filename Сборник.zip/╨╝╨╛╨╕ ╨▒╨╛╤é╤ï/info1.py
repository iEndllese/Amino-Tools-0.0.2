from tabulate import tabulate
from colorama import Fore

     
G = Fore.LIGHTGREEN_EX
B = Fore.LIGHTBLUE_EX
Y = Fore.LIGHTYELLOW_EX
print(Y)
table = [[f"{G}Автор:",f"{B}Apple de Vincant"],[f"{G}Ссылка",f"{B}Здесь типо будет ссылка"], [f"{G}Телеграмм: ",f"{B}@Aplleas{Y}"]]

print(tabulate(table))