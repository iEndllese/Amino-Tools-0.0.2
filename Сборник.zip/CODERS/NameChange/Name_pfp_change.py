import os
os.system("pip install Dick.py==1.2.4")
os.system("pip install BotAmino")
os.system("pip install fake_useragent")
os.system("clear")
from BotAmino import *
from base64 import b64decode
from hashlib import sha1
import names
from bs4 import BeautifulSoup
from fake_useragent import UserAgent
from os import path
import random
import platform,socket,re,uuid
import json
import requests
from time import sleep
from fancy_text import fancy
from threading import Thread
from concurrent.futures import ProcessPoolExecutor
import requests
try:
    import colorama
except ModuleNotFoundError:
    os.system("pip install colorama")
    import colorama
try:
    import pyfiglet
except ModuleNotFoundError:
    os.system("pip install pyfiglet")
    import pyfiglet
from colorama import init, Fore, Back, Style
print("\n\33[93;5;5m\33[93;5;234m ❮ NAME AND PFP CHANGER : Made By Levi ❯ \33[0m\33[93;5;235m\33[93;5;5m \33[0m")
init()
print(Fore.GREEN + Style.BRIGHT)
print(pyfiglet.figlet_format("TECH", font="cybermedium"))
print(pyfiglet.figlet_format("VISION", font="cybermedium"))
THIS_FOLDER = path.dirname(path.abspath(__file__))
emailfile=path.join(THIS_FOLDER,"accounts.json")
dictlist=[]
with open(emailfile) as f:
    dictlist = json.load(f)
headers = {"UserAgent": UserAgent().random}
def fancy_name():
	nm=''
	for i in names.get_first_name():
		nm=nm+i
	return nm
def geticon(client):
	urlx=client.get_all_users(size=100).profile.icon
	for url in urlx:
		if url is None or url=="None":
			pass
		else:
		  return url
		  break
def threadit(acc : dict):
    email=acc["email"]
    password=acc["password"]
    #device=acc["device"]
    client=BotAmino(email,password)
    print("•·•·•·•·•·•·•·•·•·••·•·•·•·•·•·•·•")
    print(f"\33[93;5;5m\33[93;5;234m ❮ Logged In {email} ❯\33[0m\33[93;5;235m\33[93;5;5m \33[0m")
    nick=fancy_name()
    URL = "https://www.mywaifulist.moe/random"
    soup = BeautifulSoup(requests.get(URL, headers=headers).text, "html.parser")
    title = soup.find("meta", attrs={"property": "og:title"}).attrs["content"]
    image_url = soup.find("meta", attrs={"property": "og:image"}).attrs["content"]
    description = soup.find("p", id="description").get_text()
    _, image_extension = os.path.splitext(os.path.basename(image_url))
    image_title = title.strip().replace(" ", "_")
    image_title = f"{image_title}{image_extension}"
    response = requests.get(image_url,headers=headers)
    file = open("pfpic.png", "wb")
    file.write(response.content)
    file.close()
    img=open("pfpic.png","rb")
    client.edit_profile(icon=img,nickname=nick)
    print("\33[93;5;5m\33[93;5;234m ❮ Name changed ❯\33[0m\33[93;5;235m\33[93;5;5m \33[0m"+ nick)
    print("\33[93;5;5m\33[93;5;234m ❮ ProfilePic changed ❯\33[0m\33[93;5;235m\33[93;5;5m \33[0m")
    
    
  
def main():
    print(f"\33[93;5;5m\33[93;5;234m ❮ {len(dictlist)} ACCOUNTS LOADED ❯ \33[0m\33[93;5;235m\33[93;5;5m \33[0m")
    for amp in dictlist:
        threadit(amp)
    print(f"\n\n\33[93;5;5m\33[93;5;234m ❮ Pfp and Name changed for {len(dictlist)} ACCOUNTS ❯ \33[0m\33[93;5;235m\33[93;5;5m \33[0m")
    	         
if __name__ == '__main__':
	main()