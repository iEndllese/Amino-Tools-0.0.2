import amino
import threading
import os
try:
    import colorama
except ModuleNotFoundError:
    os.system("pip install colorama")
    import colorama
try:
    import pyfiglet
except ModuleNotFoundError:
    os.system("pip install pyfiglet")
    import pyfiglet
print(colorama.Fore.BLUE)
print(colorama.Style.BRIGHT)
f = pyfiglet.Figlet(font='cyberlarge')
print (f.renderText('TECH'))
f = pyfiglet.Figlet(font='cyberlarge')
print (f.renderText('VISION'))
print("""
Youtube:
https://youtube.com/c/techvision7

Discord Server:
https://discord.gg/YMfvAxm6zF
""")
email=input("\nEnter Email >> ")
password=input("Enter password >> ")
client=amino.Client()
client.login(email=email,password=password)
n=input("Community link : ")
fok=client.get_from_code(n)
id=client.get_from_code(n).objectId
cid=fok.path[1:fok.path.index("/")]
client.join_community(cid)
print("Started joining Chats")
subclient=amino.SubClient(comId=cid,profile=client.profile)
chts=subclient.get_public_chat_threads(type="recommended", start=0, size=200).chatId

def joinall(ch):
	try:
		subclient.join_chat(chatId=ch)
		print("joined")
	except Exception:
		pass

for chats in chts:
	threading.Thread(target=joinall,args=(chats,)).start()