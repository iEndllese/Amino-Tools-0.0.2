import samino as S,json as J,time as T,pyfiglet
list=  R='\033[1;91m'; G='\033[1;92m'; Y='\033[1;93m'; B='\033[1;94m'; P='\033[1;95m'; C='\033[1;96m'; M='\033[10;95m'; K='\033[0;102m'; R2='\033[1;31m'; G2='\033[1;32m'; Y2='\033[1;33m'; B2='\033[1;34m'; P2='\033[1;35m'; C2='\033[1;36m'; M2='\033[1;30m'; K2='~'
print(B+pyfiglet.figlet_format("- Reset ")+C+pyfiglet.figlet_format("  the name -"))
print(M2+'~ '*30+P2+"\n\n\t\t\t-- Py Rahaf. --\n\n"+M2+'~ '*30)
DA = open("accounts.json")
AC= J.load(DA)
cli=S.Client()
PA = cli.get_from_link(input(Y+'\n\n    Input Chit Link --> : '+C))
print('\n\n'+M2+'~ '*30+"\n\n")
CO = PA.comId
NA=input(C+'\n\n    Input New Name --> : '+Y)
print('\n\n'+M2+'~ '*30+"\n\n")
non=0
for acc in AC:
 email = acc["email"]
 password = acc["password"]
 deviceId = acc["device"]
 pps = []
 T.sleep(0.5)
 non+=1
 try:
  cli.login(email,password)
  T.sleep(0.3)
  print(G+'    Done Login '+M2+'~~> '+Y+'['+C+f'{email}'+Y+']\n')
  cli.join_community(CO)
  T.sleep(0.4)
  print(B+'    Join Community '+M2+'~~> '+Y+'['+C+f'{email}'+Y+']\n')
  LO=S.Local(CO)
  LO.edit_profile(nickname=f'{NA} ~ {non}')
  T.sleep(0.3)
  print(M+'    Done Reset Name '+M2+'~~> '+Y+'['+C+f'{email}'+Y+']\n')
  print('\n\n'+M2+'~ '*30+"\n\n")
 except Exception as e:
  print(R+'Error '+M2+'~~> '+Y+'['+C+f'{email}'+Y+']'+M2+e+'\n')
  T.sleep(0.3)
  print('\n\n'+M2+'~ '*30+"\n\n")
  pass