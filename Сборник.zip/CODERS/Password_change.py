try:
    import colorama
except ModuleNotFoundError:
    os.system("pip install colorama")
    import colorama
try:
    import pyfiglet
except ModuleNotFoundError:
    os.system("pip install pyfiglet")
    import pyfiglet
from colorama import init, Fore, Back, Style
init()
print(Fore.GREEN + Style.BRIGHT)
print(pyfiglet.figlet_format("CHANGE", font="cybermedium"))
print(pyfiglet.figlet_format("PASSWORD", font="cybermedium"))
import amino
import secmail
import json
from bs4 import BeautifulSoup
from time import sleep
from os import path
THIS_FOLDER = path.dirname(path.abspath(__file__))
emailfile=path.join(THIS_FOLDER,"accounts.json")
dictlist=[]

with open(emailfile) as f:
    dictlist = json.load(f)
client=amino.Client("42DAFCEEA1F9FC926857D2E295C637638DE7C27FE826DBBB24A611EC30A412D99F5AD95C22711735E4")
print("Total accounts >> "+str(len(dictlist)))
pas=input("\nEnter new password:- ")
def get_message(values):
    shown=0
    while shown==0:
        try:
            sleep(10)
            f=email
            mail = secmail.SecMail()
            inbox = mail.get_messages(f)
            print('Processed')
            for Id in inbox.id:
            	msg = mail.read_message(email=f, id=Id).htmlBody
            	bs = BeautifulSoup(msg, 'html.parser')
            	images = bs.find_all('a')[0]
            	url = (images['href']+'\n')
            	if url is not None:
            	   print('Click on the Verification Url\n')
            	   print(url)
            	   shown=1
        except:
            shown=0
            pass
        return shown
def verify(values):
    while True:
        imgs=get_message(values)
        if imgs==1:
            verifycode=input("Enter code : ")
            break
    return verifycode

for acc in dictlist:
	email=acc["email"]
	password=acc["password"]
	deviceid=acc["device"]
	client.login(email,password)
	print("log")
	req=client.request_verify_code(email=email, resetPassword=True)
	if req==200:
		print('Verification Code Sent, please wait...')
		vcode=verify(email)
		x=client.change_password(email=email, password=pas, code=vcode)
		if x==200:
			d={}
			with open ("emails.txt","a") as f:
			     d["email"]=str(email)
			     d["password"]=str(pas)
			     d["device"]=str(deviceid)
			     t=json.dumps(d)
			     f.write(t+',')
			     print("Saved in File emails.txt")
			     print("Password changed")
	else:
		print("Error")
		
f= open("emails.txt","r+")  
u=(f.read())
z = u[:-1]
with open ("accounts.json","w") as file:
	file.write('['+z+']')
	file.close()
	print("Updated accounts.json file")
