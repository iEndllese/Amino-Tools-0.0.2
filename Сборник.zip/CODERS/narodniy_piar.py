import asyncio
import json
from time import sleep
import base64
import hmac
import os
from hashlib import sha1
from time import time as timestamp
from time import timezone
import aiohttp
accs=[]
soos=[]
if os.path.isfile("unused.txt"):
	with open("unused.txt","r") as fl:
		for i in fl:
			accs.append(i.split())
		if len(accs)==0:
			print("Неиспользованных аккаунтов больше нету")
			os.remove("unused.txt")
			exit()
else:
	with open("accounts.txt","r") as fl:
		for i in fl:
			account=i.split()
			if len(account) == 3:
				accs.append(account)
				with open("unused.txt","a") as fl2:
					fl2.write(f"{account[0]} {account[1]} {account[2]}\n")
		if len(accs)==0:
			print("Аккаунтов нету")
			exit()

with open("links.txt","r") as fl:
	for i in fl:
		soos.append(i.split()[0])
	if len(soos)==0:
		print("Ссылок нету")
		exit()


message=open("mes.txt", "r").read()

session=aiohttp.ClientSession()

async def admins(comId):
	try:
		async with session.get(f"{api}/x{comId}/s/user-profile?type=leaders&start=0&size=25", headers=header) as res:
			res=json.loads(await res.text())['userProfileList']
			users = []
			for i in res:
				users.append(i['uid'])
		async with session.get(f"{api}/x{comId}/s/user-profile?type=curators&start=0&size=25", headers=header) as res:
			res=json.loads(await res.text())['userProfileList']
			for i in res:
				users.append(i['uid'])
			return users
	except:
		print(await res.text())
		return []

async def sa(comId, timers):
	tz = int(-timezone // 1000)
	data = {"userActiveTimeChunkList": timers, "timestamp": int(timestamp() * 1000), "optInAdsFlags": 2147483647, "timezone": tz} 
	data = json.dumps(data)
	sig = await signature(data)
	headers = header.copy()
	headers['NDC-MSG-SIG']=sig
	async with session.post(f"{api}/x{comId}/s/community/stats/user-active-time?{header['NDCAUTH']}", headers=headers, data=data) as res:
		print(await res.json())

def device_gen():
	ur = bytes.fromhex("42") + (os.urandom(20))
	mac = hmac.new(bytes.fromhex("02B258C63559D8804321C5D5065AF320358D366F"), ur, sha1)
	return f"{ur.hex()}{mac.hexdigest()}".upper()

async def signature(data):
	return base64.b64encode(bytes.fromhex("42") + hmac.new(bytes.fromhex("F8E7A61AC3F725941E3AC7CAE2D688BE97F30B93"), data.encode("utf-8"), sha1).digest()).decode("utf-8")

async def join_inv(comId, invationId):
	try:
		data = {"timestamp": int(timestamp() * 1000)}
		if invationId: data["invitationId"] = invationId
		data = json.dumps(data)
		sig = await signature(data)
		headers=header.copy()
		headers["NDC-MSG-SIG"]=sig
		async with session.post(f"https://service.narvii.com/api/v1/x{comId}/s/community/join", data=data, headers=headers) as res:
			if res.status !=200:
				return 0
			else:
				return 1
	except:
		return 0
async def join_community(comId):
	try:
		async with session.post(f"{api}/x{comId}/s/community/join", headers=header) as res:
			if res.status !=200:
				return 0
			else:
				return 1
	except:
		return 0

async def leave_community(comId):
	try:
		async with session.delete(f"{api}/x{comId}/s/community/join", headers=header) as res:
			pass
	except:
		pass

async def active():
	headers=header.copy()
	data={"deviceID":device,
	"bundleID":"com.narvii.amino.master",
	"clientType":100,
	"timezone":900,
	"systemPushEnabled":"true",
	"deviceToken":"eJ56E7bmTM2LDzFDxnGXQb:APA91bGYLSE3guZM19jokxUS_V9wBYLXEamp4s3DNYeIpWr1PCAlghaeKSVCEj8ZFffG3g_UCg37-N6UqpEo1uNSafFf_XlIhE9TdkRf6oxqgTUrsav-OY9o0JEcJfMrOTb9gWcCszEM",
	"deviceTokenType":1,
	"timestamp":int(timestamp()*1000)}
	data = json.dumps(data)
	sig = await signature(data)
	headers["NDC-MSG-SIG"]=sig
	async with session.post(f"{api}/g/s/device", headers=headers,data=data) as res:
		pass

async def start_chat(comId, userIds,message):
	try:
		data = {
			"title": None,
			"inviteeUids": userIds,
			"initialMessageContent": message,
			"content": None,
			"timestamp": int(timestamp() * 1000),
			"type":0,
			"publishToGlobal":0
		}
		data = json.dumps(data)
		sig = await signature(data)
		headers=header.copy()
		headers["NDC-MSG-SIG"]=sig
		async with session.post(f"{api}/x{comId}/s/chat/thread", data=data, headers=headers) as res:
			return [res.status, await res.text()]
	except:
	   return 1488

async def get_users(comId, start):
	try:
		async with session.get(f"{api}/x{comId}/s/user-profile?type=recent&start={start}&size=100", headers=header) as res:
			res=json.loads(await res.text())['userProfileList']
			users = []
			for i in res:
				users.append(i['uid'])
			return users
	except:
		print(res.status)
		return []

async def get_online_users(comId, start):
	try:
		async with session.get(f"{api}/x{comId}/s/live-layer?topic=ndtopic:x{comId}:online-members&start={start}&size=100", headers=header) as res:
			res=json.loads(await res.text())['userProfileList']
			users = []
			for i in res:
				users.append(i['uid'])
			return users
	except:
		print(res.status)
		return []

async def get_from_code(code):
	async with session.get(f"{api}/g/s/link-resolution?q={code}", headers=header) as res:
		res=json.loads(await res.text())
		comId = res["linkInfoV2"]["extensions"]
		return comId
		
device = device_gen()
api="https://service.narvii.com/api/v1"
header={
	"NDCLANG": "en", 
	"NDCDEVICEID": device, 
	"SMDEVICEID": "b89d9a00-f78e-46a3-bd54-6507d68b343c", 
	"Accept-Language": "en-US", 
	"Content-Type": "application/json; charset=utf-8", 
	"User-Agent": "Dalvik/2.1.0 (Linux; U; Android 5.1.1; SM-G973N Build/beyond1qlteue-user 5; com.narvii.amino.master/3.4.33562)", 
	"Host": "service.narvii.com", 
	"Connection": "Keep-Alive", 
	"Accept-Encoding": "gzip"}

	
os.system("cls||clear")
print(f"""Простой пиар от t.me/Mrakobes1337
Кол-во неиспользованных аккаунтов: {len(accs)}
Кол-во ссылок: {len(soos)}
""")	
async def main():
	for acc in accs:
		try:
			email=acc[0]
			password=acc[1]
			devic=acc[2]
			header["NDCDEVICEID"]=devic
			data = json.dumps({
				"email": email,
				"secret": f"0 {password}",
				"deviceID": devic,
				"clientType": 100,
				"action": "normal",
				"timestamp": int(timestamp() * 1000)})
			sig = await signature(data)
			headers=header.copy()
			headers["NDC-MSG-SIG"]=sig
			
			
			async with session.post(f"{api}/g/s/auth/login", data=data, headers=headers) as res:
				res=json.loads(await res.text())
				header["NDCAUTH"]=f"sid={res['sid']}"
				uid=res["auid"]
				
			await active()
			print(f"Вошли в аккаунт {acc[0]}")
			xx=0
			for soo in soos:
				link=await get_from_code(soo)
				if soo.split("/")[3] == "c":
					soo=link["community"]["ndcId"]
					name=link["community"]["name"]
					c=await join_community(soo)
				else:
					soo=link["community"]["ndcId"]
					name=link["community"]["name"]
					invite=link["invitationId"]
					c=await join_inv(soo, invite)
				if c==0:
					print(f'\nНе смогли встутить в сообещство "{name}"\n')
					continue
				print(f'\nВступили в сообщество "{name}"')
				admin=await admins(soo)
				sleep(00.09)
				for i in range(20):
					man=await get_online_users(soo,100*i)
					if len(man)<2:
						break
					for j in man:
						if j in admin:
							man.remove(j)
					q=await start_chat(soo, man, message)
					if q != 1488:
						if q[0] == 200:
							print(f"Создали чат с онлайном на {len(man)} человек")
						elif q[1]["api:message"] =="You are banned." or q[1]["api:message"] =="You are banned":
							print("Вы забанены")
							break
						else:
							print(f"Чат не создан\n{q[1]}\n")
		 
					sleep(00.09)
					if len(man)<96:
						break
				for i in range(3):
					man=await get_users(soo,100*i)
					if len(man)<2:
						break
					for j in man:
						if j in admin:
							man.remove(j)
					q=await start_chat(soo, man, message)
					if q != 1488:
						if q[0] == 200:
							print(f"Создали чат с новыми участниками на {len(man)} человек")
						elif q[1]["api:message"] =="You are banned." or q[1]["api:message"] =="You are banned":
							print("Вы забанены")
							break
						else:
							print(f"Чат не создан\n{q[1]}\n")
					sleep(2)
					if len(man)<96:
						break
					
				await leave_community(soo)
				xx+=1
				if xx > 9:
					await active()
			
			with open("unused.txt", "r") as fl:
				lines=fl.readlines()
				lines.remove(lines[0])
			with open("unused.txt", "w") as fl:
				for line in lines:
					fl.write(line)
		except:
			with open("unused.txt", "r") as fl:
				lines=fl.readlines()
				lines.remove(lines[0])
			with open("unused.txt", "w") as fl:
				for line in lines:
					fl.write(line)
			print(f"Ошибка на аккаунте {acc[0]}")
asyncio.get_event_loop().run_until_complete(main())