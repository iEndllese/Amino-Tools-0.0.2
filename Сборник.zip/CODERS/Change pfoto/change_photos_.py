
link = ""   #grup link  or   community link

gih= ""   # user link

#dy zamen

#_______________________________________
#Don't change the things here



import time
import os
import json

try:
	import aminofix
except:
	os.system("pip install aminofix")
	import aminofix

try:
	from requests import get
except:
	os.system("pip install requests")
	from requests import get
	
from io import BytesIO
from os import path
from threading import Thread

file = path.dirname(path.abspath(__file__))
acc=path.join(file,"accounts.json")
dictlist=[]
with open(acc) as f:
    dictlist = json.load(f)
    def threadit(acc : dict):
    	email=acc["email"]
    	password=acc["password"]
    	device=acc["device"]
    	client=aminofix.Client(deviceId=device)
    	client.login(email,password)
    	print("\n  login  " ,email)
    	id=client.get_from_code(gih)
    	cid=id.path[1:id.path.index("/")]
    	client.join_community(cid)
    	chatId = id.objectId   	
    	
    	
    	print("\n geting..")
    	link_info = client.get_from_code(gih).					json["extensions"]["linkInfo"]
    	com_id, user_id = link_info["ndcId"],link_info["objectId"]
    	id=client.get_from_code(link)
    	cid=id.path[1:id.path.index('/')]
    	sub_client = aminofix.SubClient(comId=com_id, profile=client.profile)
    	
    	try :
    		sub_client.join_chat(chatId)
    	except:
    		pass
    	
    	
    	user_info = sub_client.get_user_info(userId=user_id).json
    	nickname = user_info["nickname"]
    	description = user_info["content"]
    	icon = BytesIO(get(user_info["icon"]).content)
    	profile_style = user_info["extensions"]["style"]
    	image_list = [BytesIO(get(str(user_info["mediaList"]).split("'")[1]).content)]
    	sub_client = aminofix.SubClient(comId=cid, profile=client.profile)

    	
    	id=client.get_from_code(gih)
    	cid=id.path[1:id.path.index("/")]
    	client.join_community(cid)
    	if "backgroundColor" in profile_style:
    		background_color = profile_style["backgroundColor"]
    		sub_client.edit_profile(backgroundColor=background_color)
    	elif "backgroundMediaList" in profile_style:
    		background_image = str(profile_style["backgroundMediaList"]).split("'")[1]
    		sub_client.edit_profile(backgroundImage=background_image)
    	sub_client = aminofix.SubClient(comId=cid, profile=client.profile)
    	sub_client.edit_profile(
    nickname=nickname,
    content=description,
    icon=icon,
    imageList=image_list)
    print("ok")
    		


for amp in dictlist:
	threadit(amp)