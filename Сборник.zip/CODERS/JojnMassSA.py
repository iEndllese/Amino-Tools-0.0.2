import samino
import random
from os import sys
from colorama import Fore
from json import load
from time import sleep
from multiprocessing import Process

hack_splash ='''
'##::::'##::::'###:::::'######:::'######:::::
 ###::'###:::'## ##:::'##... ##:'##... ##::::
 ####'####::'##:. ##:: ##:::..:: ##:::..:::::
 ## ### ##:'##:::. ##:. ######::. ######:::::
 ##. #: ##: #########::..... ##::..... ##::::
 ##:.:: ##: ##.... ##:'##::: ##:'##::: ##::::
 ##:::: ##: ##:::: ##:. ######::. ######:::::
..:::::..::..:::::..:::......::::......::::::
::::::'##::'#######::'####:'##::: ##:
:::::: ##:'##.... ##:. ##:: ###:: ##:
:::::: ##: ##:::: ##:: ##:: ####: ##:
:::::: ##: ##:::: ##:: ##:: ## ## ##:
'##::: ##: ##:::: ##:: ##:: ##. ####:
 ##::: ##: ##:::: ##:: ##:: ##:. ###:
. ######::. #######::'####: ##::. ##:
:......::::.......:::....::..::::..::

'''
for x in hack_splash:
	print(Fore.GREEN + x, end ='')
	sys.stdout.flush()
	sleep(0.004)
	
date_on = open("Account.json")
acs_all = load(date_on)

proxy_master = {"http": "103.1.93 .105:63141"}

client = samino.Client(proxies = proxy_master)

time_online = int(input("[Delay seconds] Time Active [enter second] >> "))

nick_randomness = ["☠꧁☬👹DEVIL👹☬꧂","꧁࿇ÐɑʀҟƑîʀɛ࿇ ","𝕯𝖆𝖗𝖐 𝕬𝖓𝖌𝖊𝖑","☠︎☬༒~VEŇØM~☠︎☬༒","꧁☬✠ƑʳᵋᵋƑᶦᴿᵋ✠☬꧂", "J҉O҉K҉E҉R҉","༒Ǥ₳₦ǤֆƬᏋЯ༒꧂", "🅑🅛🅐🅒🅚🅟🅐🅝🅣🅗🅔🅡","༄ᶦᶰᵈ᭄✿Gᴀᴍᴇʀ࿐","꧁༒☬M̷O̷N̷S̷T̷E̷R̷☬༒꧂", "ＦＵＮ乂ＧＡＭＥＲ", "꧁༒Destroyer༒√꧂", "🖤ʙʟᴀᴄᴋ ғʟᴏᴡᴇʀ🥀", "꧁༒☬Bad☬Boy☬༒꧂"," ꧁️☠️Շѧмѯ_️θѵэя☠️꧂", "⊰ŠԩąƉŏώ⊱"]

ndc_link = client.get_from_link(input("Community >> "))
ndc_id = ndc_link.comId

def join_ndc():
	try:
		client.login(email = email, password = password)
		client.edit_profile(nickname = random.choice(nick_randomness))
		sleep(time_online)
		client.join_community(ndc_id)
		local = samino.Local(ndc_id)
		print(f'''change_nick >> {nick_randomness}
ndc  >> {ndc_id}''')
		sleep(time_online)
		local.activate_status(status = 1)
	except Exception as e:
			print(e)
			
for mass_accs in acs_all:
	email = mass_accs["email"]
	password = mass_accs["password"]
	deviceId = mass_accs["device"]
	fast_1 = []
	fast_speed = Process(target = join_ndc)
	fast_speed.start()
	fast_1.append(fast_speed)
for speed in fast_1:
	speed.join()				
