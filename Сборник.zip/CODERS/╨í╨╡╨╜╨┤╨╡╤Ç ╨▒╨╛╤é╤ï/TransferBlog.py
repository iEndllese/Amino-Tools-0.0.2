
#Очередной Fix какой-то хуеты, которая мне как оказалось, неожиданно помогла. С любовью от ______❤




#Вставь ссылку на публичный пост
'''Put the blog link of a public community'''
blogLink = "http://aminoapps.com/p/f79d4l"














#Сценарий кода, если кто тупой 




import json, os
from os import path
try: import pyfiglet, aminofix
except: os.system("pip install --upgrade pyfiglet amino.fix")
finally: import pyfiglet, aminofix
from aminofix.lib.util.exceptions import AccessDenied
from pyfiglet import figlet_format
os.system('cls' if os.name=='nt' else 'clear')








#Название файла, куда вставлять ботов 

####################
emailFile = "accounts.json"
####################



#Мой тэг
print("\033[1;2;1mFixed by _______")
print("")
print("\033[1;38m")
print("\033[1;38m")




#Сам процесс


def main():
    print(f"\n\33[48;5;5m\33[38;5;234m ❮ {len(dictlist)} ЗАГРУЖЕНО АККАУНТОВ ❯ \33[0m\33[48;5;235m\33[38;5;5m \33[0m")
    for acc in dictlist:
        email=acc["email"]
        password=acc["password"]
        device=acc["device"]
        client=aminofix.Client(deviceId=device)
        try:
        	client.login(email,password)
        	print("\n°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°")
        	print("Зашел в" ,email)
        	info=client.get_from_code(blogLink)
        	comId=info.comId
        	blogId=info.objectId
        	client.join_community(comId)
        	subClient = aminofix.SubClient(comId,profile=client.profile, deviceId=device)
        	coin=client.get_wallet_info().totalCoins
        	print(f'Всего монет: {coin}')
        	timer = 0
        	while True:
        	    if coin != 0 and timer <= 10:
        	         if coin >=500:
        	             subClient.send_coins(500, blogId)
        	             print('>> Перекинул монеты')
        	             coin -= 500
        	         elif coin < 500 and coin != 0:
        	 	        subClient.send_coins(coin, blogId)
        	 	        print(f'>> Перекинул {coin} монет')
        	 	        coin -= coin
        	    else: break
        except AccessDenied: print('>> Wait 2 hours to transfer the coins')
        except Exception as e: print(e)

if __name__ == "__main__":
    file = path.dirname(path.abspath(__file__))
    acc = path.join(file, emailFile)
    dictlist=[]
    with open(acc) as f:
        dictlist = json.load(f)
    print(figlet_format("Transfer By Blog", font="big", width=60))
    main()
    exit(f"\n\n\33[48;5;5m\33[38;5;234m ❮ Transferred all coins from {len(dictlist)} ACCOUNTS ❯ \33[0m\33[48;5;235m\33[38;5;5m \33[0m")