import os 
import hmac
from concurrent.futures import ThreadPoolExecutor
from hashlib import sha1
try:
	import json
	from pyfiglet import figlet_format
except:
	os.system("pip install json-minify pyfiglet")
print(figlet_format("By Lord", font="big", width=64))
def acc_to_txt():
	file = open("accounts.json")
	accs = json.load(file)
	for acc in accs:
		email = acc["email"]
		x = open("emails.txt","a")
		em = f'{email}\n'
		x.write(em)
		x.close
	while True:
		print("all accounts converted")
		break
def generate_device_Id():
        identifier = os.urandom(20)
        return ("42" + identifier.hex() + hmac.new(bytes.fromhex("02B258C63559D8804321C5D5065AF320358D366F"), b"\x42" + identifier, sha1).hexdigest()).upper()

def txt_to_acc():
 	emails = open("emails.txt")
 	password = input("password for all accounts:")
 	try:os.remove("accounts.json")
 	except:pass
 	for email in emails:
 		email = email.strip()
 		device = generate_device_Id()
 		acc = f'{{"email": "{email}","password": "{password}","device": "{device}"}},\n'
 		x = open("newmail.txt","a")
 		x.write(acc)
 		x.close
 	while True:
 		file = open("newmail.txt")
 		readfile = (file.read())
 		remov = readfile[:-2]
 		jsonfile = open("accounts.json","a")
 		jsonfile.write("["+remov+"]")
 		print("All accounts converted")
 		os.remove("newmail.txt")
 		break
select = input("chose:\n1-emails.txt_to_accounts.json\n2-accounts.json_to_emails.txt\nchose:")
if select=="1":
	txt_to_acc()
elif select=="2":
 	acc_to_txt()
else:print("chose number")
 	
 	