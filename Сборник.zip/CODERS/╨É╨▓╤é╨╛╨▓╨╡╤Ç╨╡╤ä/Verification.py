import os
import time
import sys
try:
 import aminofix
 import json
 import requests
 from pyfiglet import figlet_format
 from webbrowser import open as OP
 from aminofix.lib.util.exceptions import VerificationRequired, ActionNotAllowed
except:
 os.system("pip install requests json pyfiglet amino.fix -U ")

def jalan(z):
        for e in z + '\n':
                sys.stdout.write(e)
                sys.stdout.flush()
                time.sleep(0.005)


A = "\033[1;91m"  
B = "\033[1;90m" 
C = "\033[1;97m" 
E = "\033[1;92m"  
H = "\033[1;93m" 
L = "\033[1;95m" 
M = "\033[1;94m" 
g = "_"
print (M+"fixed")
jalan(H+figlet_format("B Y \n Z.A.M.E.N"))

emails = open("emails.txt").read().split("\n")
print("\033[1;30;44m Verification\033[45;30m\n FOR emails.txt\033[m\n\n")

print (L+g*50)
password = input(E+"password : "+A)

print(f"\nTotal accounts {len(emails)}")


print (H)
i = 1

for email in emails:
    c = aminofix.Client()
    while True:
        try:
            c.login(email, password)
            print (L+g*30)
            print(H+f"\nDone✓ {i} {email}")
            i += 1
            break
        except VerificationRequired as e:
            print(f"\nVerification required for {email}")
            OP(e.args[0]["url"])
            print(e.args[0]["url"])
            input(" If you are finished, press Enter \n ==> ")
        except ActionNotAllowed:
            jalan(A+"\Wait an hour, then restart ")
            input()
            input()
            input()
jalan(A+"\nDone for all accounts")