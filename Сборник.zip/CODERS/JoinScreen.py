chatlink=""
import amino
import time
from os import path
import json
THIS_FOLDER = path.dirname(path.abspath(__file__))
emailfile=path.join(THIS_FOLDER,"accounts.json")
dictlist=[]
with open(emailfile) as f:
    dictlist = json.load(f)

#dicklis=dictlist.reverse()
def log(cli : amino.Client,email : str, password : str):
    try:
        cli.login(email=email,password=password)
    except Exception as e:
        print(e)
pass

def threadit(acc : dict):
    email=acc["email"]
    password=acc["password"]
    device=acc["device"]
    client=amino.Client(deviceId=device)
    log(cli=client,email=email,password=password)
    print(f"Logged In {email}")
    xd=client.get_from_code(chatlink)
    id=xd.objectId
    cid=xd.path[1:xd.path.index("/")]
    client.join_community(cid)
    subclient=amino.SubClient(comId=cid,profile=client.profile)
    subclient.join_chat(id)
    client.join_video_chat_as_viewer(comId=cid, chatId=id)
    print(f"Joined Screen Room from {email}")
    
def main():
    print(f"\n\33[48;5;5m\33[38;5;234m  {len(dictlist)} ACCOUNTS LOADED  \33[0m\33[48;5;235m\33[38;5;5m \33[0m")
    for amp in dictlist:
        threadit(amp)
    print(f"\n\n\33[48;5;5m\33[38;5;234m  {len(dictlist)} Bots Accounts joined Screen Room  \33[0m\33[48;5;235m\33[38;5;5m \33[0m")
                 
if __name__ == '__main__':
    main()