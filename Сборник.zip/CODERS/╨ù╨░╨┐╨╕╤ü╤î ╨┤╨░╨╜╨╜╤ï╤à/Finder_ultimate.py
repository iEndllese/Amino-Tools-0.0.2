import amino

from os import system
from os import _exit as quit
from time import sleep
from colorama import Fore, Style 
from pyfiglet import Figlet

banner = Figlet(font='bubble__') 
print(Fore.GREEN, Style.DIM + "By Vicious and HuntS", banner.renderText('''Finder 
Pro'''))

client = amino.Client()

while True:
	try:
		print(f'''
>>Finded tools<<
1.Get information about the user ndc
2.Get information about the user globally
''')
		finder_features = input("Functions :  ")
		
		if finder_features == "1":
			client.login(email=input("Email :  "), password=input("Password :  "))
			
			search_info = client.get_from_code(input("User link :  "))
			ndc_id = search_info.comId
			user_id = search_info.objectId
			sub_client = amino.SubClient(comId=ndc_id, profile=client.profile)
			
			finded_info = sub_client.get_user_info(userId=user_id).json
			nickname = finded_info["nickname"]
			level = finded_info["level"]
			reputation = finded_info["reputation"]
			followersCount = finded_info["membersCount"]
			
			with open("user info.txt" , "a") as finded_info:
				finded_info.write(f'''
found user :  {nickname}
status in ndc :  {level}
experience  :  {reputation}
authority :  {followersCount}
''')
			print("saved info!")
			system("clear")
			
		elif finder_features == "2":
			inside_info = input("User url :  ")
			user_Id = client.get_from_code(inside_info).objectId
			
			search_info = client.get_user_info(userId=user_Id).json
			nickname = search_info["nickname"]
			aminoId = search_info["aminoId"]
			followingCount = search_info["joinedCount"]
			
			with open("inside infos.txt", "a") as founded_info:
				founded_info.write(f'''
discovered user :  {nickname}
link :  http://aminoapps.com/u/{aminoId}
numbers following :  {followingCount}
''')
			print("Inside info saved!")
			system("clear")
		
		else:
			print(f"Features : {finder_features} not finded!")
			sleep(0.80)
			quit(1)
		
	except Exception as NotFoundInfo:
			print(f'''Wasn't able to get the information, most likely you just didn't enter the link correctly, or it's not valid :  {NotFoundInfo}''')
			sleep(0.95)
			quit(2)
			
'''[Hint] and exploitation:
	sleep - Using only in part to temporarily output the response to the terminal
	clear - mini terminal clean
	quit - fast end scenario
	All information is written to a file. Please be sure to save the script before running it
'''