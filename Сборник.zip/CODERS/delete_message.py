import os

try:
	import aminofix
	import pyfiglet
except:
	os.system("pip install amino.fix -U")
	os.system("pip install pyfiglet")
	import aminofix
	import pyfiglet
	
os.system("clear")

A = "\033[1;91m"  #احمر
Z1 = '\033[2;31m' #احمر ثاني
E = "\033[1;92m"  #اخضر
H = "\033[1;93m" #اصفر
L = "\033[1;95m" #وردي
B = '\033[2;36m'#سمائي
Y = '\033[1;34m' #ازرق فاتح 
M = "\033[1;94m" #ازرك
t = "_"

print(B+pyfiglet.figlet_format(" D e l e t e \n M e s s a g e"))

print (H+t*60)
clent = aminofix.Client()

e = input(A+"\n Email -"+E)
print (L+t*25)
p = input(A+"\n Password -"+E)
clent.login(e,p)

print (E+"\n\n  Logged in Successfully")
print (L+t*25)
link = input (A+"\n Chat Link -"+E)
print (L+t*25)
ty = int(input(A+"\nNumber Of Messages -"+E))
chh = clent.get_from_code(link)
chat = chh.objectId
com = chh.comIdPost

subclient=aminofix.SubClient(comId=com,profile=clent.profile)
mass = subclient.get_chat_messages(chatId=chat, size = ty).messageId

print (H+t*60)
print (H+t*60)
i = 1
for messageId in mass:
		try:
			subclient.delete_message(chatId=chat,messageId=messageId)
			print(A+"delete -",i)
			i = i+1
		except:
			print(M+"\nErorr")
			pass
		
		
		