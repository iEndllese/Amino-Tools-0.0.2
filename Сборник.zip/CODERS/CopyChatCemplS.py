import samino
from os import sys
from time import sleep
from colorama import Fore

explore ='''
___                         ___    _             _
(  _`\                      (  _`\ ( )           ( )_
| ( (_)   _    _ _    _   _ | ( (_)| |__     _ _ | ,_)
| |  _  /'_`\ ( '_`\ ( ) ( )| |  _ |  _ `\ /'_` )| |
| (_( )( (_) )| (_) )| (_) || (_( )| | | |( (_| || |_
(____/'`\___/'| ,__/'`\__, |(____/'(_) (_)`\__,_)`\__)
              | |    ( )_| |
              (_)    `\___/'              
'''
for x in explore:
	print(Fore.RED + x, end='')
	sys.stdout.flush()
	sleep(0.1)
	
client = samino.Client()
email = input("Email >> ")
password = input("Password >> ")
client.login(email = email, password = password)

url_info = client.get_from_link(input("Chat link >> ")).json
ndc_id = url_info["linkInfo"]["ndcId"]
thread_id = url_info["linkInfo"]["objectId"]
local = samino.Local(comId = ndc_id)
print(f'''
ndc >> {ndc_id}
chat >> {thread_id}
''')

chat_info = local.get_chat_info(chatId = thread_id).json
title = chat_info["title"]
content = chat_info["content"]
icon = chat_info["icon"]
backgroundImage = chat_info["extensions"]["bm"][1]
userAddedTopicList = chat_info["userAddedTopicList"]
membersQuota = chat_info["membersQuota"]
keywords = chat_info["keywords"]
membersCount = chat_info["membersCount"]
isPinned = chat_info["isPinned"]
membershipStatus = chat_info["membershipStatus"]
lastReadTime = chat_info["lastReadTime"]
modifiedTime = chat_info["modifiedTime"]
latestActivityTime = chat_info["latestActivityTime"]
coHosts = chat_info["extensions"]["coHost"] 
membersCanInvite = chat_info["extensions"]["membersCanInvite"]
announcement = chat_info["extensions"]["announcement"]
lastMembersSummaryUpdateTime = chat_info["extensions"]["lastMembersSummaryUpdateTime"]
createdTime = chat_info["createdTime"]
fansOnly = chat_info["extensions"]["fansOnly"]

print(f'''
title >> {title}
image >> {icon}
content >> {content}
Toplist >> {userAddedTopicList}
members_1 >> {membersQuota}
background >> {backgroundImage}
member_numbs >> {membersCount}
pinned_chat >> {isPinned}
status_member >> {membershipStatus}
last_readed >> {lastReadTime}
alerts_chat >> {announcement}
coHost >> {coHosts}
modded_time >> {modifiedTime}
last_active_time >> {latestActivityTime}
members_funct >> {membersCanInvite}
Update_User >> {lastMembersSummaryUpdateTime}
creat_time_chat >> {createdTime}
''')


setting_info = client.get_from_link(input("My chat >> ")).json
ndc_id = setting_info["linkInfo"]["ndcId"]
thread_id = setting_info["linkInfo"]["objectId"]
local.edit_chat(chatId = thread_id, title = title, content = content, icon = icon)
print("Copy ended!")