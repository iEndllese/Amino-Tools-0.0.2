import os
os.system("pip install amino.fix")
os.system("clear")
import aminofix
import pyfiglet
from colored import fore, back, style, attr
attr(0)
print(fore.THISTLE_1 + style.BOLD)
print("""@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
                          Chat Delete Scrpit by 
##################################################################""")
print(pyfiglet.figlet_format("ViCious", font="slant"))
client=aminofix.Client()
sid=input("\nSID :- ")
client.login_sid(sid)
u=input("Host Link: ")
us=client.get_from_code(u)
p=us.objectId
comId=us.path[1:us.path.index('/')]
chatl=input("Chat Link: ")
chatId=client.get_from_code(chatl).objectId
subclient=aminofix.SubClient(comId=comId, profile=client.profile)

subclient.kick(userId=p ,chatId=chatId, allowRejoin=True)
print ("Done ")
os._exit(1)