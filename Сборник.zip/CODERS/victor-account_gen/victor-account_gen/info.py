key="6d83d702-681a-425a-bace-8ed6ec0eba9f" #Your heroku key put here 
app_name="Accountgen" #you heroku app name 
YourLink="http://aminoapps.com/p/2hbbub"
createpassword="SIK890LEON" # account create password here
nickname="Vincant" #Put here account name 
private="f0349fc8-0c44-4fef-a646-d7e21a8c98c1" #you private chatId here 
chatlink="http://aminoapps.com/p/usm1lj" #Enter chat Url