import samino
from os import sys
from time import sleep
from colorama import Fore

simple = '''
ooo_____ooo__________________________
oooo___oooo__ooooo___oooo___oooo_____
oo_oo_oo_oo_oo___oo_oo___o_oo___o____
oo__ooo__oo_oo___oo___oo_____oo______
oo_______oo_oo___oo_o___oo_o___oo____
oo_______oo__oooo_o__oooo___oooo_____
_____________________________________
ooooooo__________________
oo____oo__ooooo__oo_ooo__
oooooooo_oo___oo_ooo___o_
oo____oo_oo___oo_oo____o_
oo____oo_oo___oo_oo____o_
ooooooo___oooo_o_oo____o_
_________________________

'''
for x in simple:
	print(Fore.RED + x, end ='')
	sys.stdout.flush()
	sleep(0.006)
	
client = samino.Client()
email = input("Email >> ")
password = input("Password >> ")
client.login(email = email, password = password)

com_link = input("Community >> ")
ndc_join = client.get_from_link(com_link).comId
local = samino.Local(comId = ndc_join)

while True:
	numb_users = int(input("[Enter numb] How many banned users?  >> "))
	reason_eliminate = input('''
Example:

|Spam|
|Agressive spam|
|Sexual explicit|
|Terror action|

Write reason >> ''')
	
	all_users = local.get_all_users(type = "recent", start = 0, size = numb_users)
	for nickname, level, user_id in zip(all_users.nickname, all_users.level, all_users.userId):
				try:
					local.ban(userId = user_id, reason = reason_eliminate, banType = 2)
					print(f'''
[Status: 200 > Banned]
name: {nickname}
userId: {user_id}
level:   {level} 
''')
				except Exception as e:
						print(e)
	


