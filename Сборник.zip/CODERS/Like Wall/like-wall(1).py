import aminofix,json,time,os,pyfiglet
list=  R='\033[1;91m'; G='\033[1;92m'; Y='\033[1;93m'; B='\033[1;94m'; P='\033[1;95m'; C='\033[1;96m'; M='\033[10;95m'; K='\033[0;102m'; R2='\033[1;31m'; G2='\033[1;32m'; Y2='\033[1;33m'; B2='\033[1;34m'; P2='\033[1;35m'; C2='\033[1;36m'; M2='\033[1;30m'; K2='~'
print(B+pyfiglet.figlet_format("--- Like ")+C+pyfiglet.figlet_format("            Wall ---"))
print(M2,'~ '*30,f"{P2}\n\n\t\t\t-- Py Rahaf. --\n\n{M2}",'~ '*30)
file=open('accounts.json')
data_file=json.load(file)
Client=aminofix.Client()
info_link = Client.get_from_code(input(f'{Y}\n\n    Input Profile Link --> : '+C))
print(f'\n\n{M2}','~ '*30+"\n\n")
comId=info_link.comId
userId=info_link.objectId
for account in data_file:
	email = account["email"]
	password = account["password"]
	deviceId = account["device"]
	try:
		Client.login(email,password)
		time.sleep(0.1)
		print(f'{G}    Done Login {M2}~~> {Y}[{C}{email}{Y}]\n')
		Client.join_community(comId)
		time.sleep(0.1)
		print(f'{B}    Join Community {M2}~~> {Y}[{C}{email}{Y}]\n')
		print(f'\n\n{M2}','~ '*30,"\n\n")
		subclient=aminofix.SubClient(comId,profile=Client.profile)
		time.sleep(0.01)
		comments=subclient.get_wall_comments(userId,sorting='top',start=0,size=1000)
		time.sleep(0.1)
		for txt_comment,Id_comment in zip(comments.content,comments.commentId):
			subclient.like_comment(userId=userId,commentId=Id_comment)
			print(f'{M}    Done Like {Y2}[{B}{txt_comment}{Y2}]   {Y}   [{C}{email}{Y}]\n')
			print(f'\n\n{M2}','~ '*30+"\n\n")
			time.sleep(0.2)
	except Exception as e:
		print(f'{R}Error {M2}~~> {Y}[{C}{email}{Y}]{M2}{e}\n')
		print(f'\n\n{M2}','~ '*30+"\n\n")
		time.sleep(0.2)