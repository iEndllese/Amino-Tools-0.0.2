import json
import pyfiglet
from websocket import WebSocket
import random
import string
from time import time as timestamp
import requests
import os
from time import sleep
import threading
import asyncio
import aiohttp
from nickname_generator import generate
from colorama import Fore, Style
try:
	import nickname_generator
	import colorama
	import pyfiglet
	import json
except:
	os.system("pip install nickname_generator")
	os.system("pip install colorama")
	os.system("pip install pyfiglet")
	os.system("pip install json")
	import nickname_generator
	import colorama
	import pyfiglet
	import json
os.system("clear")

#Цветовой сценарий
R = Fore.RED+Style.BRIGHT #Красный
Y = Fore.YELLOW+Style.BRIGHT #Желтый
B = Fore.BLUE+Style.BRIGHT #Синий
G = Fore.GREEN+Style.BRIGHT #Зеленый
J = "\033[2;96m" #Ярко голубой


devs=[]
sids = []
uids = []


def device_gen():
    data = "".join(random.choices(string.ascii_uppercase + string.ascii_lowercase + "_-", k=462)).replace("--", "-")
    device= requests.get(f"https://ed-generators.herokuapp.com/device?data={data}")
    return device.text

glob_dev=device_gen()

header = {'NDCLANG': 'en', 
'NDCDEVICEID': glob_dev, 
'SMDEVICEID': 'b89d9a00-f78e-46a3-bd54-6507d68b343c', 
'Accept-Language': 'en-US', 
'Content-Type': 'application/json; charset=utf-8', 
'User-Agent': 'Dalvik/2.1.0 (Linux; U; Android 5.1.1; SM-G973N Build/beyond1qlteue-user 5; com.narvii.amino.master/3.4.33562)', 
'Host': 'service.narvii.com', 
'Connection': 'Keep-Alive', 
'Accept-Encoding': 'gzip'}

session = aiohttp.ClientSession()
os.system("cls||clear")
print(J+pyfiglet.figlet_format("               Dungeon", font="doom"))

for i in "====Fixed by Apple de Vincant====":
	print(G,i,end="",flush=True)
	sleep(00.06)
rez = sorted(os.listdir())

if "session.acc" not in rez:
    vb=1
else:
    while True:
        print(Y+"\n\nИспользовать старые сессии? Y/N")
        hh=input(">> "+B)
        if hh.lower() == "y":
            vb=0
            break
        if hh.lower() == "n":
            vb=1
            break
        else:
            print(R+"Введи нормально букву")
            sleep(2)
            os.system("cls||clear")

async def signature(data):
    while True:
        try:
            async with session.post("https://ed-generators.herokuapp.com/signature", data=data) as res:	
                return await res.text()
        except:
            pass

async def smena_glob(sid,uid,nick: str = "Test"):
    data = json.dumps({
        "address": None,
        "latitude": 0,
        "longitude": 0,
        "mediaList": None,
        "eventSource": "UserProfileView",
        "nickname":nick,
        "timestamp": int(timestamp() * 1000)
    })
    sig = await signature(data)
    headers=header.copy()
    headers["NDC-MSG-SIG"]=sig
    headers["NDCAUTH"]=f"sid={sid}"
    async with session.post(f"https://service.narvii.com/api/v1/g/s/user-profile/{uid}",data=data,headers=headers):
        pass

async def upload_media(sid,data):
    
    sig = await signature(str(data))
    ln=str(len(data))
    headers=header.copy()
    headers["NDC-MSG-SIG"]=sig
    headers["NDCAUTH"]=f"sid={sid}"
    headers["Content-Length"]=ln
    headers["Content-Type"]="image/jpg"
    async with session.post(f"https://service.narvii.com/api/v1/g/s/media/upload", data=data, headers=headers) as res:
        if json.loads(await res.text())["api:statuscode"] != 0:
            print(await res.text())
        else:
            return json.loads(await res.text())["mediaValue"]

async def smena_av(sid,uid,f):
    icon=await upload_media(sid,f)
    data = json.dumps({
        "address": None,
        "latitude": 0,
        "longitude": 0,
        "mediaList": None,
        "eventSource": "UserProfileView",
        "icon":icon,
        "timestamp": int(timestamp() * 1000)
    })
    sig = await signature(data)
    headers=header.copy()
    headers["NDC-MSG-SIG"]=sig
    headers["NDCAUTH"]=f"sid={sid}"

    async with session.post(f'https://service.narvii.com/api/v1/g/s/user-profile/{uid}', headers=headers, data=data):
        pass

async def get_from_code(code):   
    async with session.get(f"https://service.narvii.com/api/v1/g/s/link-resolution?q={code}", headers=header) as res:
        return json.loads(await res.text())["linkInfoV2"]

def websocket_url(sid):
    headers = {"cookie": f"sid={sid};"}
    res=requests.get("https://aminoapps.com/api/chat/web-socket-url", headers=headers)
    if res.status_code != 200:
        pass
    else:
        return res.json()["result"]["url"]

def send_s(sid, comId):
    try:
        data = json.dumps({
            "o": {
                "actions": ["Browsing"],
                "target": f"ndc://x{comId}/",
                "ndcId": int(comId),
                "id": "831046"
            },
            "t": 304
        })
        url = websocket_url(sid)
        headers=header.copy()
        headers["NDCAUTH"]=f"sid={sid}"
        ws = WebSocket()
        ws.connect(url, headers = headers)
        ws.send(data)
    except:
        pass

def send_s2(sid, comId, chatId):
    try:
        data = json.dumps({
            "o":
                {
                    "ndcId": int(comId),
                    "threadId": chatId,
                    "joinRole": 2,
                    "id": "72446"
                },
            "t": 112
        })
        url = websocket_url(sid)
        headers=header.copy()
        headers["NDCAUTH"]=f"sid={sid}"
        ws = WebSocket()
        ws.connect(url, headers = headers)
        ws.send(data)
    except:
        pass

async def send_message(sid, comId, chatId, message: str = None, messageType: int = 0):
    try:
        data = {
            "type": messageType,
            "content": message,
            "clientRefId": int(timestamp() / 10 % 1000000000),
            "attachedObject": None,
            "timestamp": int(timestamp() * 1000)
        }
        data = json.dumps(data)
        headers=header.copy()
        headers["NDCAUTH"] = f"sid={sid}"
        async with session.post(f"https://service.narvii.com/api/v1/x{comId}/s/chat/thread/{chatId}/message", headers=headers, data=data) as res:
            return res
    except:
        pass

async def join_chat(sid, chatId, comId, userId):
    try:
        headers=header.copy()
        headers["NDCAUTH"] = f"sid={sid}"
        async with session.post(f"https://service.narvii.com/api/v1/x{comId}/s/chat/thread/{chatId}/member/{userId}", headers=headers) as res:
            pass
    except:
        pass

async def leave_chat(sid, chatId, comId, userId):
    try:
        headers=header.copy()
        headers["NDCAUTH"] = f"sid={sid}"
        async with session.delete(f"https://service.narvii.com/api/v1/x{comId}/s/chat/thread/{chatId}/member/{userId}", headers=headers) as res:
            pass
    except:
        pass

async def spam_smesh(sid, comId,chatId,message,messageType,userId):
    try:
        await join_chat(sid, chatId, comId, userId)
        await send_message(sid,comId,chatId,message,messageType)
        await leave_chat(sid,chatId,comId,userId)
    except:
        pass

async def join_community(sid, comId):
    try:
        headers=header.copy()
        headers["NDCAUTH"] = f"sid={sid}"
        async with session.post(f"https://service.narvii.com/api/v1/x{comId}/s/community/join", headers=headers) as res:
            response = json.loads(await res.text())
        if response["api:statuscode"] != 0:
            print(R+"Один из аккаунтов не вошёл в соо")
        return response
    except:
        print(R+"Один из аккаунтов не вошёл в соо")

async def leave_commutity(sid,comId):
    try:
        headers=header.copy()
        headers["NDCAUTH"] = f"sid={sid}"
        async with session.post(f'https://service.narvii.com/api/v1/x{comId}/s/community/leave', headers=headers):
            pass
    except:
        pass

async def vhod(email,password,device):
    global sids
    global uids
    global devs
    global ems
    global pars
    try:
        data = json.dumps({
            "email": email,
            "v": 2,
            "secret": f"0 {password}",
            "deviceID": device,
            "clientType": 100,
            "action": "normal",
            "timestamp": int(timestamp() * 1000)
        })
        sig = await signature(data)
        headers=header.copy()
        headers["NDC-MSG-SIG"]=sig
        headers["NDCDEVICEID"]=device
        async with session.post("https://service.narvii.com/api/v1/g/s/auth/login", headers = headers, data = data) as res:
            try:
                jsons = json.loads(await res.text())
                try:
                    res = jsons["api:message"]
                except:
                    pass
                res3 = jsons["account"]["uid"]
                res2=jsons["sid"]
                uids.append(res3)
                sids.append(res2)
                devs.append(device)
                ems.append(email)
                pars.append(password)
            except:
                try:
                    if res == "Нужна верефикация аккаунта":
                        print(f"Нужно верифицировать: {email}")
                    elif res == "Account or password is incorrect! If you forget your password, please reset it.":
                        print(f"Пароль хуйня {email}")
                    elif res == "Invalid email address.":
                        print(f"Аккаунта нету {email}")
                    elif res == "Account does not exist.":
                        print(f"Емайл введен неверно: {email}")
                    else:
                        print(f"В аккаунт {email} не вошли")
                except:
                    print(f"Какая-то ошибка при заходе {email}")
    except:
        print(f"Какая-то ошибка при заходе {email}")
os.system("cls||clear")
ems=[]
pars=[]
async def main():
    global session
    global fin_coins
    global ost_coins
    global bal
    global icon
    global unbanned
    global uids
    global devs
    global sids
    global pars
    global ems
    tasks=[]
    if vb==1:
        files = []
        for i in rez:
            try:
                if (i.split(".")[-1]).lower() == "txt":
                    files.append(i)
            except:
                pass
        for n, item in enumerate(files):
            print(f"{n+1}. {item}")
        file = int(input(G+"Введите номер файла: "))
        name = files[file-1]
        emails = open(name, "r")
        for email in emails:
            password = email.split(" ")[1]
            dev = (email.split(" ")[2]).split("\n")[0]
            email = email.split(" ")[0]
            tasks.append(asyncio.ensure_future(vhod(email,password,dev)))
        await asyncio.gather(*tasks)
        with open("session.acc","w") as fl:
            for i in range(len(sids)):
                fl.write(f"{uids[i]} {sids[i]} {devs[i]} {ems[i]} {pars[i]}\n")

    else:
        with open("session.acc","r") as fl:
            for acc in fl:
                acc=acc.split("\n")[0].split(" ")
                uids.append(acc[0])
                sids.append(acc[1])
                devs.append(acc[2])
                ems.append(acc[3])
                pars.append(acc[4])
    


    while True:
        os.system("csl||clear")
        print(G+f"\n>>> {len(sids)} <<<")
        print(Y+"""
___________________________
| Сменить ники всем ботам
| Сменить аватарки всем ботам
| Включить ботов для актива
| Список команд для чата
| Рейд всеми ботами сразу
| Запустить ботов в сообщество
—————————————————————————
\n""")

        vib = input(G+"Введите цифру: "+B)
        os.system("cls||clear")
        if vib == "1":
            try:
                print(R+"""| Один ник на все аккаунты
| Поставить ники из nick.txt
| Поставить случайный ник

АХТУНГ!

Не работает в связи со слабым запросом сигнатуры, позже пофикшу \n""")
                vibp = input(B+"Слава"+Y+"Украине")

                if vibp == "1":
                    nick = input("Введите ник: ")
                    x=0
                    tasks=[]
                    for i in range(len(sids)):
                        tasks.append(asyncio.ensure_future(smena_glob(sids[i],uids[i],nick)))
                        x+=1
                        if x > 500:
                            await asyncio.gather(*tasks)
                            tasks = []
                            x=0
                    try:
                        await asyncio.gather(*tasks)
                        tasks = []
                    except:
                        pass

                elif vibp == "2":
                    with open("nick.txt","r") as fl:
                        nicks=fl.readlines()
                    x=0
                    tasks=[]
                    for i in range(len(sids)):
                        nick = random.choice(nicks)
                        tasks.append(asyncio.ensure_future(smena_glob(sids[i],uids[i],nick)))
                        x+=1
                        if x > 500:
                            await asyncio.gather(*tasks)
                            tasks = []
                            x=0
                    try:
                        await asyncio.gather(*tasks)
                        tasks = []
                    except:
                        pass

                elif vibp == "3":
                    x=0
                    tasks=[]
                    for i in range(len(sids)):
                        nick = generate()
                        tasks.append(asyncio.ensure_future(smena_glob(sids[i],uids[i],nick)))
                        x+=1
                        if x > 500:
                            await asyncio.gather(*tasks)
                            tasks = []
                            x=0
                    try:
                        await asyncio.gather(*tasks)
                        tasks = []
                    except:
                        pass

                else:
                    print("Допустим")
                    sleep(2)
                    os.system("cls||clear")
                os.system("cls||clear")

            except Exception as e:
                print(e)
                sleep(2)
                os.system("cls||clear")

        elif vib == "2":
            try:
                print(R+"""| Поставить одну аву 
| Поставить случайную аву из папки

АХТУНГ!

Не работает в связи со слабым запросом сигнатуры, позже пофикшу \n""")
                vibp = input(B+"Слава"+Y+"Украине")

                if vibp == "1":
                    pic=open("AvatarAmino.png","rb")
                    x=0
                    tasks=[]
                    for i in range(len(sids)):
                        tasks.append(asyncio.ensure_future(smena_av(sids[i],uids[i],pic)))
                        x+=1
                        if x > 500:
                            await asyncio.gather(*tasks)
                            tasks = []
                            x=0
                    try:
                        await asyncio.gather(*tasks)
                        tasks = []
                    except:
                        pass
                    pic.close()

                elif vibp == "2":
                    pth=f"{os.getcwd()} \\avs"
                    fn=os.listdir(pth)
                    avs=[]
                    for fl in fn:
                        avs.append(open(f"{pth}\\{fl}", "rb").read())
                    x=0
                    tasks=[]
                    for i in range(len(sids)):
                        pic=random.choice(avs)
                        tasks.append(asyncio.ensure_future(smena_av(sids[i],uids[i],pic)))
                        x+=1
                        if x > 500:
                            await asyncio.gather(*tasks)
                            tasks = []
                            x=0
                    try:
                        await asyncio.gather(*tasks)
                        tasks = []
                    except:
                        pass
                    avs=[]

                else:
                    print("Хуёвый из тебя выбиратель")
                    sleep(2)
                    os.system("cls||clear")
                
                os.system("cls||clear")

            except Exception as e:
                print(e)
                sleep(2)
                os.system("cls||clear")
        
        elif vib == "3":
            try:
                ll = input("Введите ссылку на сообщество ")
                fromc=await get_from_code(ll)
                soo=(fromc["path"].split("x")[1]).split("/")[0]
                x = 0
                for i in range(len(sids)):
                    x+=1
                    threading.Thread(target=send_s,args=(sids[i],soo)).start()
                    if x > 50:
                        x=0
                        sleep(2)
                        

                print("Готово")
                sleep(2)
                os.system("cls||clear")
            
            except Exception as e:
                print(e)
                sleep(2)
                os.system("cls||clear")

        elif vib == "4":
            try:
                print("""| Войти в чат
| Выйти из чата
| Стать зрителем чата""")
                
                vibp = input("Введите цифру: ")
                ll = input("Введите ссылку на чат: ")
                fromc=await get_from_code(ll)
                soo=(fromc["path"].split("x")[1]).split("/")[0]
                chid = fromc["extensions"]["linkInfo"]["objectId"]
                
                if vibp == "1":
                    x=0
                    tasks=[]
                    for i in range(len(sids)):
                        tasks.append(asyncio.ensure_future(join_chat(sids[i],chid,soo,uids[i])))
                        x+=1
                        if x > 500:
                            await asyncio.gather(*tasks)
                            tasks = []
                            x=0
                    try:
                        await asyncio.gather(*tasks)
                        tasks = []
                    except:
                        pass
                    print("Готово")
                    sleep(2)
                    os.system("cls||clear")

                elif vibp == "2":
                    x=0
                    tasks=[]
                    for i in range(len(sids)):
                        tasks.append(asyncio.ensure_future(leave_chat(sids[i],chid,soo,uids[i])))
                        x+=1
                        if x > 500:
                            await asyncio.gather(*tasks)
                            tasks = []
                            x=0  
                    try:
                        await asyncio.gather(*tasks)
                        tasks = []
                    except:
                        pass
                    print("Готово")
                    sleep(2)
                    os.system("cls||clear")

                elif vibp == "3":
                    x = 0
                    for i in range(len(sids)):
                        x+=1
                        threading.Thread(target=send_s2,args=(sids[i],soo, chid)).start()
                        if x > 50:
                            x=0
                            sleep(2)


                    print("Готово")
                    sleep(2)
                    os.system("cls||clear")

                else:
                    print("Хуёвый из тебя выбиратель")
                    sleep(2)
                    os.system("cls||clear")


            except Exception as e:
                print(e)
                sleep(2)
                os.system("cls||clear")



        elif vib == "5":
            try:
                ll = input("Введите ссылку на чат: ")
                fromc=await get_from_code(ll)
                soo=(fromc["path"].split("x")[1]).split("/")[0]
                chid = fromc["extensions"]["linkInfo"]["objectId"]
                mes = input("Введите сообщение: ")
                mestype = int(input("Введите тип сообщений: "))
                x=0
                tasks=[]
                while True:
                    try:
                        for i in range(len(sids)):
                            x+=1
                            tasks.append(asyncio.ensure_future(spam_smesh(sids[i],soo,chid,mes,mestype,uids[i])))
                            if x > 1000:
                                    x=0
                                    await asyncio.gather(*tasks)
                                    tasks=[]
                    except:
                        pass


            except Exception as e:
                print(e)
                sleep(2)
                os.system("cls||clear")
            
        elif vib == "6":
            try:
                print("""| Войти в сообщество
| Выйти из сообщества""")
                
                vibp = input("Введите цифру: ")

                if vibp == "1":
                    ll = input("Введите ссылку на соо: ")
                    fromc=await get_from_code(ll)
                    soo=(fromc["path"].split("x")[1]).split("/")[0]
                    x=0
                    tasks=[]
                    for i in range(len(sids)):
                        tasks.append(asyncio.ensure_future(join_community(sids[i],soo)))
                        x+=1
                        if x > 500:
                            await asyncio.gather(*tasks)
                            tasks = []
                            x=0
                    try:
                        await asyncio.gather(*tasks)
                        tasks = []
                    except:
                        pass
                    print("Готово")
                    sleep(2)
                    os.system("cls||clear")

                elif vibp == "2":
                    ll = input("Введите ссылку на соо: ")
                    fromc=await get_from_code(ll)
                    soo=(fromc["path"].split("x")[1]).split("/")[0]
                    x=0
                    tasks=[]
                    for i in range(len(sids)):
                        tasks.append(asyncio.ensure_future(leave_commutity(sids[i],soo)))
                        x+=1
                        if x > 500:
                            await asyncio.gather(*tasks)
                            tasks = []
                            x=0  
                    try:
                        await asyncio.gather(*tasks)
                        tasks = []
                    except:
                        pass
                    print("Готово")
                    sleep(2)
                    os.system("cls||clear")
                
                else:
                    print("Хуёвый из тебя выбиратель")
                    sleep(2)
                    os.system("cls||clear")



            except Exception as e:
                print(e)
                sleep(2)
                os.system("cls||clear")

        else:
            print("Пашол нахуй, введи нормально")
            sleep(2)
            os.system("cls")


loop = asyncio.get_event_loop()
loop.run_until_complete(main())
